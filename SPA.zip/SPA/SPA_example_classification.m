%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Comparison of the common discetizations and classification methods
%%% for different numbers of Voronoi discretization boxes (clusters) K
%%% with the Scalable Probabilistic Approximation (SPA) algorithm based on the iterative
%%% solution of the regularized optimization problem:
%%%
%%% {S,gamma}= argmin[sum_{t=1}^T {|| X(:,t)-S*gamma(:,t)||
%%%       +reg_param/(d(K-1)K)\sum_{i=1}^{d}\sum_{k1,k2=1}^{K}(S(i,k1)-S(i,k2))^2}]
%%%
%%% where X is a (dxT)-matrix of the data in R^d (d-is the feature dimension
%%% of the given data X and T is the statistics size, e.g., a number
%%% of the equidistant time step realizations in the time series). 
%%% Variable pi is
%%% a (mxT)-matrix of probability m-state probabilty distributions of labels
%%% for columns of matrix X.
%%%
%%%  C is a R^{dxK} operator
%%% projecting back from the discrete probabilistic discretization gamma to
%%% R^d, and gamma(:,t) is a discrete probability distribution vector with
%%% K elements. Element gamma(i,t) of this vector describes a probability
%%% for the data instance X(:,t) to belong to a particular Voronoi discretization
%%% cell i. reg_param controls the impact of the Tikhonov-regularization
%%% term that penalizes the distances between the centers of the individual
%%% Voronoi-cells during the adaptive discretization.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear all
close all
addpath('ProgramFiles/')

randn('seed',1);
rand('seed',1);

%%% Example: WDBC breast cancer classification problem.

data_file_name='classification_WDBC';

load(['Data/' data_file_name])


%%% Normalisation of the data to the interval (-1,1) and 
%%% and making it dimensionless (scaling-away the physical
%%% units)

[n,T]=size(X);
for i=1:n
    mm(i)=  max(abs(X(i,:)));
    if mm>0
        X(i,:)=X(i,:)./mm(i);
    end
end

%%% Sets ranges for  the Tikhonov
%%% regularization parameter reg_param, for the S-matrix in the SPA-problem 
reg_param=[1e-14 1e-8 1e-7 1e-6 1e-4 1e-3];

%%% Set  regularisation matrices GO_weights

GO_weights=ones(n);
%%% Set the range of numbers of discretization boxes (clusters)
K=[2:2:12 15:5:30];
%%% To avoid trapping in local minima, methods require to be started
%%% at the N_anneal randomly generated points in parameter space  
N_anneal=5;
%%% Setting a proportion of the data used for training
fraction=0.75;
%%% Setting a number of random bisections intro training and validation 
%%% sets - the final results are averaged over these random bisections
N_ens=5; 

%%% Setting a number of neurons for the pattern recognition ANN
N_neurons=5;

L_kmeans=zeros(1,length(K));L_ANN=zeros(1,length(K));
L_gmm=zeros(1,length(K));L_gmm_ANN=zeros(1,length(K));
L_opd=zeros(1,length(K));L_opd_mark=zeros(1,length(K));
D_kmeans=zeros(1,length(K));D_opd=zeros(1,length(K));
D_som=zeros(1,length(K));D_gmm=zeros(1,length(K));
for n_ens=1:N_ens
    disp(['%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%'])
    disp(['%% Multiple cross-validation: step number ' num2str(n_ens)])
    disp(['%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%'])
    %%% Generating a random bisection of the data into the training and 
    %%% the validation sets 
    ind_perm=randperm(T);
    [~,ind_back]=sort(ind_perm,'ascend');
    X=X(:,ind_perm);
    pi=pi(:,ind_perm);
    X_train=X(:,1:floor(fraction*T));pi_train=pi(:,1:floor(fraction*T));
    X_valid=X(:,(1+floor(fraction*T)):T);pi_valid=pi(:,(1+floor(fraction*T)):T);
    %%% Computing and visualizing  the K-means discretizations, the probailistic
    %%%% discretizations
    %%% with fixed K-means centroids and the optimal probabilistic discretizations of
    %%% the regularized optimization problem
    
    
    for ind_K=1:length(K)
        disp(['Computation for ' num2str(K(ind_K)) ' discretization boxes (clusters)'])
        %%% Common discretisations and classifications (K-means, Bayes, ANN/SOM, GMM)
        out_kmeans{ind_K,n_ens}= KMeans_Classify(X_train,pi_train,K(ind_K), X_valid, pi_valid,N_anneal);
        out_ANN{ind_K,n_ens}= ANN_Classify(X_train,pi_train,K(ind_K), X_valid, pi_valid,N_anneal,N_neurons);
        out_som{ind_K,n_ens}= SOM_Classify(X_train,X_valid,K(ind_K),N_anneal);
        out_gmm{ind_K,n_ens}= GMM_Classify(X_train,pi_train,K(ind_K), X_valid, pi_valid,N_anneal,N_neurons);
        %%% SPA-discretisation and classification
        out_opd{ind_K,n_ens} = ConvMeansParallelRegularize_Classify_GO(X_train,pi_train,...
            K(ind_K),N_anneal,out_kmeans{ind_K,n_ens}.gamma,reg_param,X_valid,pi_valid,N_neurons,GO_weights);
        
        D_som(ind_K)=D_som(ind_K)+1/N_ens*out_som{ind_K,n_ens}.err_discr_valid;
        D_gmm(ind_K)=D_gmm(ind_K)+1/N_ens*out_gmm{ind_K,n_ens}.err_valid_discr;
        L_kmeans(ind_K)=L_kmeans(ind_K)+1/N_ens*out_kmeans{ind_K,n_ens}.err_valid_pred;
        L_ANN(ind_K)=L_ANN(ind_K)+1/N_ens*out_ANN{ind_K,n_ens}.err_valid_pred;
        L_opd(ind_K)=L_opd(ind_K)+1/N_ens*out_opd{ind_K,n_ens}.L_pred_valid;
        L_gmm(ind_K)=L_gmm(ind_K)+1/N_ens*out_gmm{ind_K,n_ens}.err_valid_pred;
        L_gmm_ANN(ind_K)=L_gmm_ANN(ind_K)+1/N_ens*out_gmm{ind_K,n_ens}.err_valid_pred_NN;
        %L_opd_mark(ind_K)=L_opd_mark(ind_K)+1/N_ens*out_opd{ind_K,n_ens}.L_pred_Markov;
        D_kmeans(ind_K)=D_kmeans(ind_K)+1/N_ens*out_kmeans{ind_K,n_ens}.err_valid_discr;
        D_opd(ind_K)=D_opd(ind_K)+1/N_ens*out_opd{ind_K,n_ens}.L_discr_valid;
    end
    save(['Output/' data_file_name '_intermediate_v2.mat']);
end

L_opd=N_ens/n_ens*L_opd;%L_opd_mark=N_ens/n_ens*L_opd_mark;
L_ANN=N_ens/n_ens*L_ANN;L_kmeans=N_ens/n_ens*L_kmeans;
L_gmm_ANN=N_ens/n_ens*L_gmm_ANN;L_gmm=N_ens/n_ens*L_gmm;
D_opd=N_ens/n_ens*D_opd;D_kmeans=N_ens/n_ens*D_kmeans;D_som=N_ens/n_ens*D_som;
D_gmm=N_ens/n_ens*D_gmm;

figure;subplot(1,2,1);plot(K,D_kmeans,'r--x','LineWidth',2);hold on;
plot(K,D_som,'b--x','LineWidth',2);
plot(K,D_opd,'g--x','LineWidth',2);
plot(K,D_gmm,'c--x','LineWidth',2);legend('Kmeans','NN-SOM','OPA','GMM');
xlabel('number of clusters','FontSize',20);
ylabel('l2 approximation error for validation data','FontSize',20);
set(gca,'FontSize',20,'LineWidth',2);
subplot(1,2,2);plot(K,L_kmeans,'r:x','LineWidth',2);hold on;
plot(K,L_ANN,'r--x','LineWidth',2);
plot(K,L_opd,'g--x','LineWidth',2);
plot(K,L_gmm,'c:o','LineWidth',2);
plot(K,L_gmm_ANN,'c--x','LineWidth',2);
legend('Kmeans+Bayes','KMeans+ANN','SPA+ANN','GMM+Bayes','GMM+ANN');
xlabel('number of clusters','FontSize',20);
ylabel('TV classification error for validation data','FontSize',20);
set(gca,'FontSize',20,'LineWidth',2);

