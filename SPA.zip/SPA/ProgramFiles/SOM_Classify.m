function [out_kmeans]= SOM_Classify(x,x_valid,K,N_anneal)   
    [n,T]=size(x);
    out_kmeans.err_discr_valid=SOM_cluster(x,x_valid,K,N_anneal);
end
function err_valid=SOM_cluster(x,x_valid,K,N_anneal)

[D,T]=size(x);
for n=1:N_anneal
    net = selforgmap([1 K]);
    net.trainParam.showWindow = 0;
    
    net = train(net,x);
    %view(net)
    [gamma,nnn] = net(x);
    classes = vec2ind(gamma);
    col='rgbmcky';
    %figure;hold on;
    C=zeros(D,K);
    sum_gamma=sum(gamma,2);
    for t=1:T
        for k=1:K
            C(:,k)=C(:,k)+gamma(k,t)*x(:,t);
        end
    end
    for k=1:K
        if sum_gamma(k)>0
        C(:,k)=C(:,k)/sum_gamma(k);
        end
    end
    err=(1/T/D)*sum(sum((x-C*gamma).^2,2));
    if n==1
        L_fin=err;
        net_final=net;
    end
    if err<L_fin
        L_fin=err;
        net_final=net;
    end
end
[D,T]=size(x_valid);
[gamma_valid,nnn] = net(x_valid);
err_valid=(1/T/D)*sum(sum((x_valid-C*gamma_valid).^2,2));
end