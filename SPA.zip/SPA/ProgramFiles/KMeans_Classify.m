function [out_kmeans]= KMeans_Classify(X,pi,K, X_valid, pi_valid,N_anneal)   
    [n,T]=size(X);m=size(pi,1);
    [out_kmeans.idx_fin,out_kmeans.C_fin,L_fin]=kmeans(X',K,'Replicates',N_anneal,'MaxIter',1000);
    out_kmeans.gamma=zeros(K,T);
    for ttt=1:T
       out_kmeans.gamma(out_kmeans.idx_fin(ttt),ttt)=1;
    end
    out_kmeans.C_fin=out_kmeans.C_fin';
    out_kmeans.L_fin=0;
    for t=1:T
        err=X(:,t)-out_kmeans.C_fin(:,out_kmeans.idx_fin(t));
        out_kmeans.L_fin=out_kmeans.L_fin+err'*err;
    end
    out_kmeans.L_fin=out_kmeans.L_fin/T/n;
    gam{1}=out_kmeans.gamma;p{1}=pi;
    P=lambdasolver_quadprog_Classify(gam,p);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    out_kmeans.err_pred=0;
    for t=1:T
       %dev_pred=pi(:,t)-P*out_kmeans.gamma;
       %dev_pred=KLdivergence(pi(:,t),P*out_kmeans.gamma(:,t))
        out_kmeans.err_pred= out_kmeans.err_pred+...
            KLdivergence(pi(:,t),P*out_kmeans.gamma(:,t));%dev_pred'*dev_pred;
    end
     out_kmeans.err_pred= out_kmeans.err_pred/(m*T);
%        err_disc=0;
%    for t=1:T
%       dev_disc=X(:,t)-C*out_kmeans.gamma;
%       err_disc=err_disc+dev_disc'*dev_disc;
%    end
%    err_disc=err_disc/(d*T);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    T=size(X_valid,2);
    out_kmeans.gamma_valid=zeros(K,T);
    out_kmeans.err_valid_discr=0;
    out_kmeans.err_valid_pred=0;
    for t=1:T
        for k=1:K
            vvv=X_valid(:,t)-out_kmeans.C_fin(:,k);
            dist(k)=vvv'*vvv; 
        end
        [~,ii]=min(dist);
        out_kmeans.gamma_valid(ii,t)=1;
        %ppp=pi_valid(:,t)-P*out_kmeans.gamma_valid(:,t);
        out_kmeans.err_valid_pred=out_kmeans.err_valid_pred+KLdivergence(pi_valid(:,t),P*out_kmeans.gamma_valid(:,t));%ppp'*ppp;
        out_kmeans.err_valid_discr=out_kmeans.err_valid_discr+dist(ii);
    end
    out_kmeans.err_valid_discr=out_kmeans.err_valid_discr/(T*n);
    out_kmeans.err_valid_pred=out_kmeans.err_valid_pred/(T*m);
    out_kmeans.P=P;