function [out_kmeans]= GMM_Classify(X,pi,K, X_valid, pi_valid,N_anneal,N_neurons)
[n,T]=size(X);m=size(pi,1);
GMModel=fitgmdist(X',K,'Replicates',N_anneal,...
    'RegularizationValue',1e-8,...
    'Options',statset('Display','off','MaxIter',1500));
out_kmeans.gamma=GMModel.posterior(X')';
out_kmeans.C_fin=GMModel.mu';
out_kmeans.L_fin=0;
for t=1:T
    x_rec=out_kmeans.C_fin*out_kmeans.gamma(:,t);
    err=X(:,t)-x_rec;
    out_kmeans.L_fin=out_kmeans.L_fin+err'*err;
end
out_kmeans.L_fin=out_kmeans.L_fin/T/n;
gam{1}=out_kmeans.gamma;p{1}=pi;
P=lambdasolver_quadprog_Classify(gam,p);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
out_kmeans.err_pred=0;
for t=1:T
    %dev_pred=pi(:,t)-P*out_kmeans.gamma;
    %dev_pred=KLdivergence(pi(:,t),P*out_kmeans.gamma(:,t))
    out_kmeans.err_pred= out_kmeans.err_pred+...
        KLdivergence(pi(:,t),P*out_kmeans.gamma(:,t));%dev_pred'*dev_pred;
end
out_kmeans.err_pred= out_kmeans.err_pred/(m*T);
%        err_disc=0;
%    for t=1:T
%       dev_disc=X(:,t)-C*out_kmeans.gamma;
%       err_disc=err_disc+dev_disc'*dev_disc;
%    end
%    err_disc=err_disc/(d*T);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T=size(X_valid,2);
out_kmeans.gamma_valid=zeros(K,T);
out_kmeans.err_valid_discr=0;
out_kmeans.err_valid_pred=0;
for t=1:T
    for k=1:K
        vvv=X_valid(:,t)-out_kmeans.C_fin(:,k);
        dist(k)=vvv'*vvv;
    end
    [~,ii]=min(dist);
    out_kmeans.gamma_valid(ii,t)=1;
    %ppp=pi_valid(:,t)-P*out_kmeans.gamma_valid(:,t);
    out_kmeans.err_valid_pred=out_kmeans.err_valid_pred+KLdivergence(pi_valid(:,t),P*out_kmeans.gamma_valid(:,t));%ppp'*ppp;
    out_kmeans.err_valid_discr=out_kmeans.err_valid_discr+dist(ii);
end
out_kmeans.err_valid_discr=out_kmeans.err_valid_discr/(T*n);
out_kmeans.err_valid_pred=out_kmeans.err_valid_pred/(T*m);
out_kmeans.P=P;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[n,T]=size(X);
T_valid=size(X_valid,2);
for n=1:N_anneal
    net = patternnet(N_neurons);
    net.trainParam.showWindow = 0;
    net = train(net,out_kmeans.gamma,pi,'useParallel','yes');
    err=0;
    for t=1:T
        err=err+KLdivergence(pi(:,t),net(out_kmeans.gamma(:,t)));
    end
    err=err/(m*T);
    if n==1
        LLL=err;
        net_final=net;
    else
        if LLL>err
            LLL=err;
            net_final=net;
        end
    end
end
%view(net)
out_kmeans.err_valid_pred_NN = 0;
for t=1:T_valid
    out_kmeans.err_valid_pred_NN = out_kmeans.err_valid_pred_NN+KLdivergence(pi_valid(:,t),net_final(out_kmeans.gamma_valid(:,t)));
end
out_kmeans.err_valid_pred_NN=out_kmeans.err_valid_pred_NN/(m*T_valid);
out_kmeans.net=net_final;

